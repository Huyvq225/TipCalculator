//
//  SettingsViewController.swift
//  Tip Calculator
//
//  Created by Vo Quang Huy on 03/05/2017.
//  Copyright © 2017 Vo Quang Huy. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    @IBOutlet weak var colorPreview: UIView!

    @IBOutlet weak var redColorSlider: UISlider!
    
    @IBOutlet weak var greenColorSlider: UISlider!
    
    @IBOutlet weak var blueColorSlider: UISlider!
    
    let defaults = UserDefaults.standard
    
    func isKeyPresentInUserDefaults(key: String) -> Bool {
        return defaults.object(forKey: key) != nil
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        var redColor: Float = 0
        if isKeyPresentInUserDefaults(key: "redColorSlider"){
            redColor = defaults.float(forKey: "redColorSlider")
        }
        redColorSlider.value = Float(redColor)
        
        var greenColor: Float = 0
        if isKeyPresentInUserDefaults(key: "greenColorSlider"){
            greenColor = defaults.float(forKey: "greenColorSlider")
        }
        greenColorSlider.value = Float(greenColor)
        
        var blueColor: Float = 0.5
        if isKeyPresentInUserDefaults(key: "blueColorSlider"){
            blueColor = defaults.float(forKey: "blueColorSlider")
        }
        blueColorSlider.value = Float(blueColor)
        colorPreview.backgroundColor = UIColor(red: CGFloat(redColor), green: CGFloat(greenColor), blue: CGFloat(blueColor), alpha: 1.0)


    }
    
    @IBAction func setRedColor(_ sender: Any) {
        colorPreview.backgroundColor = UIColor(red: CGFloat(redColorSlider.value), green: CGFloat(greenColorSlider.value), blue: CGFloat(blueColorSlider.value), alpha: 1.0)
        defaults.set(redColorSlider.value, forKey: "redColorSlider")
        defaults.synchronize()
    }
    @IBAction func setGreenColor(_ sender: Any) {
        colorPreview.backgroundColor = UIColor(red: CGFloat(redColorSlider.value), green: CGFloat(greenColorSlider.value), blue: CGFloat(blueColorSlider.value), alpha: 1.0)
        defaults.set(greenColorSlider.value, forKey: "greenColorSlider")
        defaults.synchronize()
    }

    @IBAction func setBlueColor(_ sender: Any) {
        colorPreview.backgroundColor = UIColor(red: CGFloat(redColorSlider.value), green: CGFloat(greenColorSlider.value), blue: CGFloat(blueColorSlider.value), alpha: 1.0)
        defaults.set(blueColorSlider.value, forKey: "blueColorSlider")
        defaults.synchronize()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

}
