//
//  ViewController.swift
//  Tip Calculator
//
//  Created by Vo Quang Huy on 03/05/2017.
//  Copyright © 2017 Vo Quang Huy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var billField: UITextField!
    @IBOutlet weak var billLabel: UILabel!
    @IBOutlet weak var tipLeftLabel: UILabel!
    @IBOutlet weak var tipLabel: UILabel!
    @IBOutlet weak var totalLeftLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var tipControll: UISegmentedControl!

    let defaults = UserDefaults.standard

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        billLabel.textColor = UIColor(red: CGFloat(defaults.float(forKey: "redColorSlider")), green: CGFloat(defaults.float(forKey: "greenColorSlider")), blue: CGFloat(defaults.float(forKey: "blueColorSlider")), alpha: 1.0)
        
        tipControll.tintColor = UIColor(red: CGFloat(defaults.float(forKey: "redColorSlider")), green: CGFloat(defaults.float(forKey: "greenColorSlider")), blue: CGFloat(defaults.float(forKey: "blueColorSlider")), alpha: 1.0)
        
        tipLeftLabel.textColor = UIColor(red: CGFloat(defaults.float(forKey: "redColorSlider")), green: CGFloat(defaults.float(forKey: "greenColorSlider")), blue: CGFloat(defaults.float(forKey: "blueColorSlider")), alpha: 1.0)
        
        tipLabel.textColor = UIColor(red: CGFloat(defaults.float(forKey: "redColorSlider")), green: CGFloat(defaults.float(forKey: "greenColorSlider")), blue: CGFloat(defaults.float(forKey: "blueColorSlider")), alpha: 1.0)
        
        totalLeftLabel.textColor = UIColor(red: CGFloat(defaults.float(forKey: "redColorSlider")), green: CGFloat(defaults.float(forKey: "greenColorSlider")), blue: CGFloat(defaults.float(forKey: "blueColorSlider")), alpha: 1.0)
        
        totalLabel.textColor = UIColor(red: CGFloat(defaults.float(forKey: "redColorSlider")), green: CGFloat(defaults.float(forKey: "greenColorSlider")), blue: CGFloat(defaults.float(forKey: "blueColorSlider")), alpha: 1.0)
        
        billField.textColor = UIColor(red: CGFloat(defaults.float(forKey: "redColorSlider")), green: CGFloat(defaults.float(forKey: "greenColorSlider")), blue: CGFloat(defaults.float(forKey: "blueColorSlider")), alpha: 1.0)
    }

    @IBAction func onTap(_ sender: Any) {
        view.endEditing(true)
    }

    @IBAction func tipCalculator(_ sender: Any) {
        let tipPercentages = [0.18, 0.2, 0.25]
        
        let bill = Double(billField.text!) ?? 0
        let tip = bill * tipPercentages[tipControll.selectedSegmentIndex]
        let total = bill + tip
        
        tipLabel.text = String(format: "$%.2f" , tip)
        totalLabel.text = String(format: "$%.2f" , total)


    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}

